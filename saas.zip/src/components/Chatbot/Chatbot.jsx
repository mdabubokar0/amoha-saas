import React from 'react'

export const Chatbot = () => {
  return (
    <div className='absolute'>Chatbot</div>
  )
}
